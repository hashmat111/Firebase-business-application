package com.example.busineesmodel;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button admins, users;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        admins =(Button) findViewById(R.id.admin);
        users =(Button) findViewById(R.id.user);

        admins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the Intent object of this class Context() to Second_activity class
                Intent intent = new Intent(MainActivity.this, loginAdmin.class);
                // now by putExtra method put the value in key, value pair key is
                // message_key by this key we will receive the value, and put the string





//
//                intent.putExtra("message_key", resultant);
//                intent.putExtra("message_key1",height);
//                intent.putExtra("message_key2",weight);
//                intent.putExtra("message_key3",age);

                // start the Intent
                startActivity(intent);

            }
        });

        users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the Intent object of this class Context() to Second_activity class
                Intent intent = new Intent(MainActivity.this, UserPage.class);
                // now by putExtra method put the value in key, value pair key is
                // message_key by this key we will receive the value, and put the string






//                intent.putExtra("message_key", resultant);
//                intent.putExtra("message_key1",height);
//                intent.putExtra("message_key2",weight);
//                intent.putExtra("message_key3",age);

                // start the Intent
                startActivity(intent);

            }
        });



    }
}