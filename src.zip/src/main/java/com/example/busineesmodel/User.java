package com.example.busineesmodel;

public class User {


String color,count,name;


    public String getColor() {
        return color;
    }

    public String getCount() {
        return count;
    }

    public String getName() {
        return name;
    }


}


