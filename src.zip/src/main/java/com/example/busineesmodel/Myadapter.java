package com.example.busineesmodel;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.helper.widget.Layer;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Myadapter extends RecyclerView.Adapter<Myadapter.MyViewHolder> {

    Context context;
    ArrayList<User> list;

    // constructor of the class Myadapter
    public Myadapter(Context context, ArrayList<User> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new MyViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        User user=list.get(position);
        holder.name.setText(user.getName());
        holder.color.setText(user.getColor());
        holder.count.setText(user.getCount());
    }

    @Override
    public int getItemCount() {
        return list.size();

    }

    public static  class MyViewHolder extends RecyclerView.ViewHolder{
        TextView name,color,count;

        public MyViewHolder(@NonNull View itemView) {

            super(itemView);
            name=itemView.findViewById(R.id.tvfirstName);
            color=itemView.findViewById(R.id.tvlastName);
            count=itemView.findViewById(R.id.tvage);

        }
    }
}

