package com.example.busineesmodel;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
//import android.content.DialogInterface;
import android.os.Bundle;
//import android.view.View;
import android.widget.Button;
import android.widget.EditText;
//import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class adminPage extends AppCompatActivity {

    EditText pname, pcolors, pcount;
    Button AddData;
    //ImageButton imageButton;
    AlertDialog.Builder builder;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);
        builder = new AlertDialog.Builder(this);

        pname = (EditText) findViewById(R.id.productName);
        pcolors = (EditText) findViewById(R.id.colors);
        pcount = (EditText) findViewById(R.id.countProudct);


        AddData = (Button) findViewById(R.id.addProduct);
        //addData below is replaced with lambda easy way
        AddData.setOnClickListener(view -> {

            if (pname.length() == 0 || pcolors.length() == 0 || pcount.length() == 0) {
                Toast.makeText(adminPage.this, "all fields are mandatory:)", Toast.LENGTH_LONG).show();


            } else {
                HashMap<String, Object> m = new HashMap<>();

                m.put("name", pname.getText().toString());
                m.put("color", pcolors.getText().toString());
                m.put("count", pcount.getText().toString());


                FirebaseDatabase.getInstance().getReference().child("products").push().setValue(m);

                //  Toast.makeText(adminPage.this,"added successfully:)",Toast.LENGTH_LONG ).show();

                //make the fields empty after submission
                pname.setText("");
                pcount.setText("");
                pcolors.setText("");

                //dialog pop up

                builder.setMessage("Do you want to add more products ?");
                builder.setCancelable(false);
                builder.setPositiveButton("No", (dialogInterface, i) -> finish());
                builder.setNegativeButton("Yes", (dialogInterface, i) -> dialogInterface.cancel());
                AlertDialog alert = builder.create();
                alert.setTitle("logout");
                alert.show();


            }

        });


    }
}